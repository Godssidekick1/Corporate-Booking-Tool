// ── lib/book/types.ts ──────────────────────────────────────────────────────
// Shared shapes across the booking flow pages. Mirrors exactly what
// /api/book/search returns (see FlatFlightResult there) — kept here so
// price/passengers pages don't redeclare it.
// ─────────────────────────────────────────────────────────────────────────────

// ── Traveler profile (employees.traveler_profile) ────────────────────────────
// One per employee — their own stable, per-person details, filled in once on
// /profile and reused to autofill passenger slot 1 (plus CustomerInfo)
// whenever they book for themselves. Deliberately excludes firstName/lastName
// (employees.full_name is the source of truth). Identity fields mirror
// AddPassengerDetails' PassengerDetail exactly, confirmed against a real
// request body, so no translation layer is needed between this and the
// passenger form. Contact fields mirror CustomerInfo the same way.
//
// This is the corporate record of who this person is and how to reach them —
// when booking for yourself, these fields are locked on the booking page and
// can only be changed here, on /profile, not overridden per-trip.
export interface TravelerProfile {
  title: string                  // "MR" | "MRS" | "MS" | "MSTR" etc — matches PassengerDetail.Title
  gender: string                 // "Male" | "Female"
  dateOfBirth: string            // "DD/MM/YYYY" — matches PassengerDetail.DateOfBirth format
  passportNumber?: string        // optional — only relevant for international travel
  issuingCountry?: string
  nationality?: string
  passportExpiryDate?: string    // "DD/MM/YYYY"
  mealPreference?: string        // matches PassengerDetail.MealCode
  // Contact details — mirrors CustomerInfo exactly, matching format below.
  email?: string
  mobile?: string
  address?: string
  city?: string
  state?: string
  zipCode?: string
}

export interface StopInfo {
  code: string
  city: string
  arrivalDateTime: string
  departureDateTime: string | undefined
}

export interface PenaltyLine {
  paxType: string
  text: string   // free-text as Amadeus sends it, e.g. "INR3000" or "0" — never parsed, just trimmed
}

// One fare option for this flight. Real responses seen so far only ever
// contain one of these per flight, but Amadeus's own shape
// (PricingInfos.PricingInfo) is an array, and production may return more
// than one — rendered as however many actually come back, not assumed to be 1.
export interface FareOption {
  pricingKey: string
  currency?: string
  totalFare?: number
  baseFare?: number
  tax?: number
  isNdc?: boolean
  refundable?: boolean
  fareType?: string
  fareBasis?: string
  mealIncluded?: boolean       // PricingInfo.Meal === "YES" — treated as chargeable/optional unless explicitly "YES"
  changePenalties: PenaltyLine[]
  cancelPenalties: PenaltyLine[]
  // Branded fare tier — the airline's own named fare product for this
  // option (e.g. "ECOVALU" / "ECO VALUE"), distinct from fareType (NRM/etc,
  // an internal refundability class). brandedServices is the perk list,
  // already split from the provider's pipe-delimited string into an array
  // so pages don't need to know about that delimiter. All optional since
  // not every fare/provider returns branded data.
  brandedFareName?: string
  brandedFareDescription?: string
  brandedServices?: string[]
}

export interface FlatFlightResult {
  flightKey: string
  provider: string
  isLcc: boolean
  itemNo: string
  cabin?: string
  bookingCode?: string

  origin?: {
    code: string
    name: string
    city: string
    dateTime: string
    terminal?: string
  }

  destination?: {
    code: string
    name: string
    city: string
    dateTime: string
    terminal?: string
  }

  airline?: {
    code: string
    name: string
  }

  stopCount: number
  stops: StopInfo[]

  // Overall itinerary duration currently used elsewhere.
  duration?: string

  // Total duration for each journey/direction, including connection time.
  // e.g. ['12:30'] for one-way or ['12:30', '13:10'] for round-trip.
  totalDuration?: string

  availableSeats?: number
  checkInBaggageKg?: string
  cabinBaggageKg?: string
  fareOptions: FareOption[]

  pricingKey?: string
  currency?: string
  totalFare?: number
  baseFare?: number
  isNdc?: boolean
  refundable?: boolean
}

// ── Seat selection ────────────────────────────────────────────────────────────
// One flight leg's worth of seat map data, plus what the traveler picked.
// Mirrors lib/amadeus/client.ts's SeatListDetail/PassengerSeatSelection —
// kept separate here since the frontend only needs a slice of those fields.
//
// Confirmed against a real full-cabin response:
// - ColumnNo is NOT usable as a column position — it's 0 for every real seat
//   in the entire cabin (only becomes 4 on the BLANK aisle-gap filler cell in
//   each row). Column position comes from array order within the row instead.
// - SeatDesignator is already in the exact "22-B" (row-hyphen-letter) form
//   AddPassenger expects for real, selectable seats — no derivation needed.
//   Only "hidden"/inaccessible rows (Assignable: false, Message: "hide",
//   TravelClassCode: "NA") show the numeric junk form ("11", "21"...) instead;
//   those rows aren't real seat picks and should be excluded entirely.
// - SeatStatus (not SeatAvailability, which can misleadingly say "Available"
//   on an occupied seat) is the field that determines selectability:
//   "OPEN" = free/selectable, "OCCUPIED" = taken, "BLANK" = the walking aisle
//   itself (not a seat at all), "NoSeat" = no physical seat at this position
//   (e.g. galley/lavatory). Only OPEN seats are ever clickable.
export interface SeatCell {
  rowNo: number
  seatDesignator: string   // ready-to-use lettered form, e.g. "22-B" — pass straight through to AddPassenger's SeatListDetails
  seatAlignment: string    // "Window" | "Middle" | "Aisle"
  seatStatus: string       // "OPEN" (selectable) | "OCCUPIED" | "BLANK" (aisle, not a seat) | "NoSeat" (no seat here) | other hidden/unavailable values
  seatFee: number
  paid: boolean
  travelClassCode: string
  flightNumber: string
  flightTime: string
  equipment: string
  carrier: string
  group: string
  classOfService: string
  optionalServiceRef: string
  segmentRef: string
  exitSeats: string         // e.g. "EXIT1A" when this row is an exit row, "" otherwise
  hidden: boolean           // true for rows the fare/cabin can't see (Assignable: false, Message: "hide", TravelClassCode: "NA") — excluded from rendering entirely
}

export interface LegSeatMap {
  legIndex: number
  origin: string
  destination: string
  flightNumber: string
  flightTime: string
  columns: number
  rows: number
  available: boolean       // false if the airline/fare simply has no seat map for this leg — flow proceeds without seats
  seats: SeatCell[]
}

// Selected seat per passenger per leg, in the exact shape AddPassenger wants
// back (see PassengerSeatSelection in lib/amadeus/client.ts). Keyed by
// legIndex so the passengers page can group them back into
// PassengerDetails[i].SeatListDetails.
export interface SelectedSeat {
  legIndex: number
  SeatDesignator: string
  SeatFee: string
  FlightNumber: string
  FlightTime: string
  Equipment: string
  SeatAlignment: string
  OptionalServiceRef: string
  Group: string
  ClassOfService: string
  Carrier: string
  Paid: boolean
  SegmentRef: string
}

export function formatTime(iso: string | undefined) {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
  } catch {
    return '—'
  }
}

export function formatDayLabel(iso: string | undefined) {
  if (!iso) return ''
  try {
    return new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })
  } catch {
    return ''
  }
}